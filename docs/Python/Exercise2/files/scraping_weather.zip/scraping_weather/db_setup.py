import mysql.connector

from scraping_weather.env.message import Message
from scraping_weather.env.application_env import ApplicationEnv

# Access to DB
con = mysql.connector.connect(host=ApplicationEnv.DB_HOST, user=ApplicationEnv.DB_USER, password=ApplicationEnv.DB_PASSWORD)
curs = con.cursor()

try:
    # CREATE TABLE for WEATHER_INFO
    curs.execute(
        '''CREATE TABLE PRACTICE.WEATHER_INFO
        (
            WATHER_DATE DATE PRIMARY KEY,
            RAINFALL DOUBLE(3, 1),
            TEMP DOUBLE(3, 1),
            HUMIDITY DOUBLE(3, 1),
            WIND DOUBLE(3, 1),
            SUNSHINE_HOURS DOUBLE(3, 1),
            SNOWFALL DOUBLE(3, 1),
            DAY_CONDITION VARCHAR(20),
            NIGHT_CONDIFITON VARCHAR(20),
            CREATE_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )'''
    )

    con.commit()
except Exception as e:
    # ROLLBACK
    print(Message.ERROR_FORMAT.format(Message.ERR_DB, e))
    con.rollback()
finally:
    curs.close()
    con.close()



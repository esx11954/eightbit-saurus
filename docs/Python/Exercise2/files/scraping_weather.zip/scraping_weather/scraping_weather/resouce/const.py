# Constant types class

from typing import Any

class _ConstMeta(type):
    class ConstError(TypeError):
        pass

    # setter制御
    def __setattr__(self, __name: str, __value: Any) -> None:
        if __name in self.__dict__:
            # 定数に値を代入することを禁止する
            raise TypeError(f'定数の値を変更することはできません: {__name}')
        else:
            self.__setattr__(__name, __value)

class Const(metaclass=_ConstMeta):
    # DB
    DB_USE_DATABASE = 'USE {0}'

    # スクレイピング
    SCRAPE_URL = 'https://www.data.jma.go.jp/stats/etrn/view/daily_s1.php'
    SCRAPE_PARAM = '?prec_no=44&block_no=47662&year={0}&month={1}'

    # 取得する気象情報テーブルの列インデックス
    SCP_COL_DAY = 0                 # 日付
    SCP_COL_RAINFALL = 3            # 降水量
    SCP_COL_TEMP = 6                # 温度
    SCP_COL_HUMIDITY = 9            # 湿度
    SCP_COL_WIND = 11               # 風速
    SCP_COL_SUNSHINEHOURS = 16      # 日照時間
    SCP_COL_SNOWFALL = 17           # 降雪
    SCP_COL_DAYCONDITION = 19       # 概況(昼)
    SCP_COL_NIGHTCONDITION = 20     # 概況(夜)
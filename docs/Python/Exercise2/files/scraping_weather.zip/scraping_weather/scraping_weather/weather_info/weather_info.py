import bs4
from decimal import Decimal
from resouce.const import Const 

# 気象情報クラス
class WeatherInfo:

    # コンストラクタ
    # 引数1: 1行分の気象情報リスト
    def __init__(self, prm : list[bs4.ResultSet]):
        # 引数を秘匿変数に代入
        self.__wi = prm

    # -----プロパティ-----

    # 1行分の気象情報リスト
    @property
    def wi(self):
        return self.__wi

    # 日付
    @property
    def day(self):
        if len(self.__wi) > 0 : return str(self.__wi[Const.SCP_COL_DAY].text.strip())
    
    # 降水量
    @property
    def rainfall(self):
        if len(self.__wi) > 0 : return self.StrToFloatOrNone(self.__wi[Const.SCP_COL_RAINFALL].text.strip())
    
    # 気温
    @property
    def temp(self):
        if len(self.__wi) > 0 : return self.StrToFloatOrNone(self.__wi[Const.SCP_COL_TEMP].text.strip())
    
    # 湿度
    @property
    def humidity(self):
        if len(self.__wi) > 0 : return self.StrToFloatOrNone(self.__wi[Const.SCP_COL_HUMIDITY].text.strip())
    
    # 風速
    @property
    def wind(self):
        if len(self.__wi) > 0 : return self.StrToFloatOrNone(self.__wi[Const.SCP_COL_WIND].text.strip())
    
    # 日照時間
    @property
    def sunshine_hours(self):
        if len(self.__wi) > 0 : return self.StrToFloatOrNone(self.__wi[Const.SCP_COL_SUNSHINEHOURS].text.strip())
    
    # 降雪量
    @property
    def snowfall(self):
        if len(self.__wi) > 0 : return self.StrToFloatOrNone(self.__wi[Const.SCP_COL_SNOWFALL].text.strip())
    
    # 気象概況(昼)
    @property
    def day_condition(self):
        if len(self.__wi) > 0 : return str(self.__wi[Const.SCP_COL_DAYCONDITION].text.strip())
    
    # 気象概況(夜)
    @property
    def night_condition(self):
        if len(self.__wi) > 0 : return str(self.__wi[Const.SCP_COL_NIGHTCONDITION].text.strip())


    # -----setter-----
  
    # 1行分の気象情報リスト
    @wi.setter
    def wi(self, value):
        self.__wi = value

    # -----関数-----

    # 文字列型をフロート型へ変換を試みる
    # 引数1: 文字列
    # 戻り値: Float型の小数またはNone
    def StrToFloatOrNone(self, value):
        if(type(value) is str):
            try:
                return float(value)
            except ValueError:
                return 'null'
        else:
            return None
from typing import Any

class _ConstMeta(type):
    class ConstError(TypeError):
        pass

    # setter制御
    def __setattr__(self, __name: str, __value: Any) -> None:
        if __name in self.__dict__:
            # 定数に値を代入することを禁止する
            raise TypeError(f'定数の値を変更することはできません: {__name}')
        else:
            self.__setattr__(__name, __value)


class ApplicationEnv(metaclass=_ConstMeta):
    # -----DB設定-----
    DB_HOST = 'localhost'
    DB_USER = 'root'
    DB_PASSWORD = 'root'
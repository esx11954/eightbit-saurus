import sys
import requests
import mysql.connector
from resouce.const import Const
from env.message import Message
from env.application_env import ApplicationEnv
from weather_info.weather_info import WeatherInfo
from bs4 import BeautifulSoup

## 準備. 気象情報を取得する'年月'の入力を受け付ける

## 1. スクレイピングを行うWEBサイトのURLを組み立てる

## 2. スクレイピングを行うWEBサイトからHTMLをレスポンスさせる

## 3. HTMLを基にBeautifulSoup オブジェクトを作る

## 4. 【確認処理】 気象情報名を出力する

## 5. 気象情報の表を取得する

## 6. 【確認処理】 表の内容を出力する

## 7. DBへ接続して気象情報をINSERTする

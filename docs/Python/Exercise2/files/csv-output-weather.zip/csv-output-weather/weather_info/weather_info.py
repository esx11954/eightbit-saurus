# 気象情報クラス
class WeatherInfo:

    # コンストラクタ
    def __init__(self):
        self.__day = None
        self.__rainfall = None
        self.__temp = None
        self.__create_date = None

    # -----プロパティ-----

    # 日付
    @property
    def day(self):
        return self.__day
    
    # 降水量
    @property
    def rainfall(self):
        return self.__rainfall
    
    # 気温
    @property
    def temp(self):
        return self.__temp
    
    # 作成日時
    @property
    def create_date(self):
        return self.__create_date


    # -----setter-----

    # 日付
    @day.setter
    def day(self, value):
        self.__day = value

    # 降水量
    @rainfall.setter
    def rainfall(self, value):
        self.__rainfall = value

    # 気温
    @temp.setter
    def temp(self, value):
        self.__temp = value

    # 作成日時
    @create_date.setter
    def create_date(self, value):
        self.__create_date = value
import sys
import mysql.connector
from env.message import Message
from env.application_env import ApplicationEnv
from weather_info.weather_info import WeatherInfo

## 準備. 気象情報を取得する範囲(YYYY/MM/DD)の入力を受け付ける

## 1. DBへ接続して気象情報をSELECTする

## 2. ファイルへ書き込みする
